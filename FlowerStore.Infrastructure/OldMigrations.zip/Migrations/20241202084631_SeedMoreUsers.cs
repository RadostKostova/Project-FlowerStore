﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FlowerStore.Infrastructure.Migrations
{
    public partial class SeedMoreUsers : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "adminId");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "testId");

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "FirstName", "LastName", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "Phone", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[,]
                {
                    { "9a53e015-990d-4cd0-ae04-2d402060c207", 0, "c8486c9e-28b6-4450-af63-910b731c1018", "test@test.com", false, "Test", "Test", false, null, "TEST@TEST.COM", "TEST@TEST.COM", "AQAAAAEAACcQAAAAEMuzU2xI24UYVkvBynxTPE88tu3LqPYO9sg2YA+NkWku3Pb6OaDARosmQrYtYBSXWg==", "1234567700", null, false, "4f757ae4-6e9e-4049-bd92-c3b361b004ed", false, "test@test.com" },
                    { "cd15aecc-5e73-4b62-bf2d-0dd9f14ab72e", 0, "91a02d2b-8e44-48d1-8aa9-06287d9b2508", "admin@mail.com", false, "Admin", "Admin", false, null, "ADMIN@MAIL.COM", "ADMIN@MAIL.COM", "AQAAAAEAACcQAAAAEHJm8BWGMMSJewdu3E4lWwdoDX2lHMd3IdSQLqlxa3aIMCzVXJdbT4nizQGQj13Jlw==", "1234567890", null, false, "d1a8d43f-5c82-408f-81f2-8451f87430bf", false, "admin@mail.com" },
                    { "d5f40bd1-8e34-4354-8996-0f884be97351", 0, "dc611720-d030-495c-9b91-752de114b4f4", "random@random.com", false, "Random", "User", false, null, "RANDOM@RANDOM.COM", "RANDOM@RANDOM.COM", "AQAAAAEAACcQAAAAEPBptdbbDuFQV09aIkIn6Y5y1Q+Jkl6gaBnwTwMkZn+LFWspPBraEp3I6kY0C6eQ6A==", "0987654321", null, false, "ac1e3b75-4c78-405f-86a4-f7532e1660ee", false, "random@random.com" },
                    { "e50f5dc0-298d-4807-88f0-73b88c82e128", 0, "19c5b70a-da6f-447f-a96f-6f1b478da9a2", "guest@guest.com", false, "Guest", "Guest", false, null, "GUEST@GUEST.COM", "GUEST@GUEST.COM", "AQAAAAEAACcQAAAAEPbKwnSIAImH5bU/EhuEBfkh8k+Lc+PZ145pL7yR7CyWa5BnQ54Q/PNxxYajM3P2OQ==", "1234567800", null, false, "214bd227-7432-44c3-8c10-08ae47060f18", false, "guest@guest.com" }
                });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3463));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3465));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3466));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3468));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 5,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3469));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 6,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3470));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 7,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3471));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 8,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3472));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 9,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3473));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 10,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3473));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 11,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3474));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 12,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3475));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 13,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3476));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 14,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3477));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 15,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 8, 46, 31, 340, DateTimeKind.Utc).AddTicks(3482));

            migrationBuilder.UpdateData(
                table: "AspNetUserClaims",
                keyColumn: "Id",
                keyValue: 1,
                column: "UserId",
                value: "cd15aecc-5e73-4b62-bf2d-0dd9f14ab72e");

            migrationBuilder.UpdateData(
                table: "AspNetUserClaims",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "ClaimValue", "UserId" },
                values: new object[] { "Guest Guest", "e50f5dc0-298d-4807-88f0-73b88c82e128" });

            migrationBuilder.InsertData(
                table: "AspNetUserClaims",
                columns: new[] { "Id", "ClaimType", "ClaimValue", "UserId" },
                values: new object[,]
                {
                    { 3, "user:fullname", "Test Test", "9a53e015-990d-4cd0-ae04-2d402060c207" },
                    { 4, "user:fullname", "Random User", "d5f40bd1-8e34-4354-8996-0f884be97351" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetUserClaims",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "AspNetUserClaims",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "cd15aecc-5e73-4b62-bf2d-0dd9f14ab72e");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "e50f5dc0-298d-4807-88f0-73b88c82e128");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "9a53e015-990d-4cd0-ae04-2d402060c207");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "d5f40bd1-8e34-4354-8996-0f884be97351");

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "FirstName", "LastName", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "Phone", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[,]
                {
                    { "adminId", 0, "e8783192-16f4-4820-9239-201f064f6cab", "admin@mail.com", false, "Admin", "Admin", false, null, "ADMIN@MAIL.COM", "ADMIN@MAIL.COM", "AQAAAAEAACcQAAAAELGjroEYIM+6c8SntS1i4BoWfOGKEwN5zIVkmJafeF2PXvLNU2eh2d2lS7Rp1v4kwA==", "1234567890", null, false, "d3207cab-ff7c-4954-b122-70be22a258b3", false, "admin@mail.com" },
                    { "testId", 0, "8d0898a3-74c2-404e-a058-fd7f40a0cbc5", "test@test.com", false, "Test", "Test", false, null, "TEST@TEST.COM", "TEST@TEST.COM", "AQAAAAEAACcQAAAAEH3We/klgP62XKrXBNJJXEtwh4e/vJzXd/7KjNJwZn9UvOHUUvPRod5Si+ZJEo5adA==", "1234567800", null, false, "31121064-d83e-45cf-a482-91c257407f04", false, "test@test.com" }
                });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2519));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2520));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2521));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2521));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 5,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2522));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 6,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2523));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 7,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2523));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 8,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2524));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 9,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2524));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 10,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2525));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 11,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2526));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 12,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2526));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 13,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2527));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 14,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2527));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 15,
                column: "DateAdded",
                value: new DateTime(2024, 11, 28, 12, 41, 17, 396, DateTimeKind.Utc).AddTicks(2528));

            migrationBuilder.UpdateData(
                table: "AspNetUserClaims",
                keyColumn: "Id",
                keyValue: 1,
                column: "UserId",
                value: "adminId");

            migrationBuilder.UpdateData(
                table: "AspNetUserClaims",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "ClaimValue", "UserId" },
                values: new object[] { "Test Test", "testId" });
        }
    }
}
