﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FlowerStore.Infrastructure.Migrations
{
    public partial class AdminIdChanged : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OrderHistories",
                schema: "dbo" 
            );

            migrationBuilder.DropTable(
                name: "OrderProductHistory",
                schema: "dbo" 
            );

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "cd15aecc-5e73-4b62-bf2d-0dd9f14ab72e");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "9a53e015-990d-4cd0-ae04-2d402060c207",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "22a0832c-43e8-4337-9dcf-1f49b723a776", "AQAAAAEAACcQAAAAEJDT81ZoC1rRijnKbqyLFQlB1PMgx6MF9HtWwlDWXh9Zqw7AjIjHZ2yCxwwv+IsRhQ==", "21237d48-5042-4f0f-adc8-4ea9448932a5" });

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "d5f40bd1-8e34-4354-8996-0f884be97351",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "7ba193f6-3ccd-4362-b43d-1b18a3c62c01", "AQAAAAEAACcQAAAAECJo8Wr9NRsQbWRX0za1xnuWOXDNOLzTpPVFvyAFB+Zp8FtuLwQG8JpfiiL/sl/YVA==", "a17d6d5f-56d6-48bc-a36f-fff88a79bdcd" });

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "e50f5dc0-298d-4807-88f0-73b88c82e128",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "72030175-a956-4ade-bcb7-09560549a38d", "AQAAAAEAACcQAAAAEN7P/vpQhb9Oq630VkvVERsYL+KU7DXfpLoTYFaZfpEXSN0dsLTNjic6FcGR+xScDg==", "2e6cf04e-c733-4655-97df-d3a0780cc8cf" });

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "FirstName", "LastName", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "Phone", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[] { "a21722de-a984-476a-a7d7-8e48dadde907", 0, "f7792b32-51e5-4b47-b82c-952a81e7df92", "admin@mail.com", false, "Admin", "Admin", false, null, "ADMIN@MAIL.COM", "ADMIN@MAIL.COM", "AQAAAAEAACcQAAAAEONWfOZXz/GhuGMLwY112JqZxa7gUNQ4YYvmv0hjjV9dFM2ionQp84wiJFuXqzBbTA==", "1234567890", null, false, "69ab5ecd-d19d-4968-8750-c2ec39fae365", false, "admin@mail.com" });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1622));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1623));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1624));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1625));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 5,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1626));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 6,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1627));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 7,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1628));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 8,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1629));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 9,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1630));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 10,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1631));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 11,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1632));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 12,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1633));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 13,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1634));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 14,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1635));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 15,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 58, 15, 695, DateTimeKind.Utc).AddTicks(1635));

            migrationBuilder.UpdateData(
                table: "Reviews",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedAt",
                value: new DateTime(2024, 12, 2, 11, 58, 15, 679, DateTimeKind.Local).AddTicks(3606));

            migrationBuilder.UpdateData(
                table: "Reviews",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedAt",
                value: new DateTime(2024, 12, 2, 11, 58, 15, 679, DateTimeKind.Utc).AddTicks(3616));

            migrationBuilder.UpdateData(
                table: "Reviews",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedAt",
                value: new DateTime(2024, 12, 2, 13, 58, 15, 679, DateTimeKind.Utc).AddTicks(3617));

            migrationBuilder.UpdateData(
                table: "AspNetUserClaims",
                keyColumn: "Id",
                keyValue: 1,
                column: "UserId",
                value: "a21722de-a984-476a-a7d7-8e48dadde907");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OrderHistories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "Order history identifier")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<string>(type: "nvarchar(max)", nullable: false, comment: "User identifier"),
                    OrderStatusId = table.Column<int>(type: "int", nullable: false, comment: "Order status identifier"),
                    OrderId = table.Column<int>(type: "int", nullable: false, comment: "Order identifier")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderHistories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderHistories_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_OrderHistories_OrderStatuses_OrderStatusId",
                        column: x => x.OrderStatusId,
                        principalTable: "OrderStatuses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OrderProductHistory",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "Order product identifier")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderHistoryId = table.Column<int>(type: "int", nullable: false, comment: "Order history identifier"),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false, comment: "Price per unit"),
                    ProductId = table.Column<int>(type: "int", nullable: false, comment: "Product identifier"),
                    ProductName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false, comment: "Product name at the time of order"),
                    Quantity = table.Column<int>(type: "int", nullable: false, comment: "Quantity of product")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderProductHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderProductHistory_OrderHistories_OrderHistoryId",
                        column: x => x.OrderHistoryId,
                        principalTable: "OrderHistories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "a21722de-a984-476a-a7d7-8e48dadde907");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "9a53e015-990d-4cd0-ae04-2d402060c207",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "1f3bf4d9-21c6-49c2-804b-d73cd64711f2", "AQAAAAEAACcQAAAAEPQ5Nt+NyAYdyMPoS+lnPCpcK3ALTS3gnfTKilFLcJXhvBepB3A2HQsK3PDnkOPvZw==", "1d293faa-3aa6-4f84-b937-3c91369167c8" });

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "d5f40bd1-8e34-4354-8996-0f884be97351",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "4ff60a47-d80c-4e3f-98b5-9f9792456ead", "AQAAAAEAACcQAAAAEFU4RidkscbNR2pxNiv6Nn//KTiqiMXSNKb9SlZ76iklSHE8HYFBdPvqPk572iNrtA==", "e91f11f1-f1ab-4d49-95df-6736f4cf1f7b" });

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "e50f5dc0-298d-4807-88f0-73b88c82e128",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "a063b113-6e36-4e72-9094-912304fce430", "AQAAAAEAACcQAAAAEHirl5BTPD35vA+K6NVf9y7LX9oLdZesw2ltwzhoNLTl89y4Cra07pBRYDiUf2LYBA==", "505c6428-df73-4780-967c-add733353bab" });

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "FirstName", "LastName", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "Phone", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[] { "cd15aecc-5e73-4b62-bf2d-0dd9f14ab72e", 0, "f920f831-14d9-43d9-ad4b-15ece5e81e22", "admin@mail.com", false, "Admin", "Admin", false, null, "ADMIN@MAIL.COM", "ADMIN@MAIL.COM", "AQAAAAEAACcQAAAAEE3bRIBt0Wy7k22dSBzuwpCu56k7OntUtT9amm40hVDgeU9FLxOO0n4fx6adprLN3Q==", "1234567890", null, false, "bc8db4e2-df65-436e-9ebd-332757d8ee2d", false, "admin@mail.com" });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4591));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4593));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4594));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4594));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 5,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4595));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 6,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4596));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 7,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4597));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 8,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4597));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 9,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4598));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 10,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4599));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 11,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4600));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 12,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4600));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 13,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4601));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 14,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4602));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 15,
                column: "DateAdded",
                value: new DateTime(2024, 12, 2, 9, 37, 33, 319, DateTimeKind.Utc).AddTicks(4607));

            migrationBuilder.UpdateData(
                table: "Reviews",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedAt",
                value: new DateTime(2024, 12, 2, 11, 37, 33, 304, DateTimeKind.Local).AddTicks(6227));

            migrationBuilder.UpdateData(
                table: "Reviews",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedAt",
                value: new DateTime(2024, 12, 2, 11, 37, 33, 304, DateTimeKind.Utc).AddTicks(6233));

            migrationBuilder.UpdateData(
                table: "Reviews",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedAt",
                value: new DateTime(2024, 12, 2, 13, 37, 33, 304, DateTimeKind.Utc).AddTicks(6234));

            migrationBuilder.UpdateData(
                table: "AspNetUserClaims",
                keyColumn: "Id",
                keyValue: 1,
                column: "UserId",
                value: "cd15aecc-5e73-4b62-bf2d-0dd9f14ab72e");
        }
    }
}
